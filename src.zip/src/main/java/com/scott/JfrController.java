package com.scott;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import jdk.jfr.Configuration;
import jdk.jfr.Event;
import jdk.jfr.Label;
import jdk.jfr.Name;
import jdk.jfr.Recording;

/**
 * Controls a JFR recording for a single benchmark run.
 *
 * <p>Two control back-ends are supported:
 * <ul>
 *   <li><b>api</b>  – uses the in-process {@link jdk.jfr.Recording} API.
 *       Requires no external binary. Recommended.</li>
 *   <li><b>cli</b>  – shells out to {@code jcmd}, resolved from
 *       {@code java.home/bin/jcmd} first, then from {@code PATH}.
 *       Requires a full JDK (not a JRE).</li>
 * </ul>
 */
public final class JfrController implements AutoCloseable {

    private final boolean enabled;
    private final boolean useApi;
    private final String start;
    private final String stop;
    private final String runName;
    private final String settings;
    private final String startCommandTemplate;
    private final String stopCommandTemplate;
    private final Path outputFile;
    private boolean dumped;

    /** Active in-process recording when {@code useApi} is {@code true}. */
    private Recording recording;

    /** Optional perf integration; null when not configured. */
    private PerfRecorder perfRecorder;
    private final PerfConfig perfConfig;
    private final Path runDir;

    private JfrController(boolean enabled,
                          boolean useApi,
                          String start,
                          String stop,
                          String runName,
                          String settings,
                          String startCommandTemplate,
                          String stopCommandTemplate,
                          Path outputFile,
                          PerfConfig perfConfig,
                          Path runDir) {
        this.enabled = enabled;
        this.useApi = useApi;
        this.start = start;
        this.stop = stop;
        this.runName = runName;
        this.settings = settings;
        this.startCommandTemplate = startCommandTemplate;
        this.stopCommandTemplate = stopCommandTemplate;
        this.outputFile = outputFile;
        this.perfConfig = perfConfig;
        this.runDir = runDir;
    }

    public static JfrController create(ProfilingConfig profiling, String runName, Path runDir) throws IOException {
        if (profiling == null || !profiling.enabled()) {
            return new JfrController(false, false, null, null, null, null, null, null, null, null, null);
        }

        String resolvedName = profiling.filename().replace("${runName}", runName);
        Path output = runDir.resolve(resolvedName);
        Files.createDirectories(output.getParent());

        String defaultStart = "JFR.start name=${runName} settings=${settings} filename=${outputFile}";
        String defaultStop  = "JFR.stop name=${runName} filename=${outputFile}";

        boolean useApi = "api".equalsIgnoreCase(profiling.control());

        return new JfrController(
                true,
                useApi,
                profiling.start(),
                profiling.stop(),
                runName,
                profiling.settings(),
                profiling.startCommand() != null ? profiling.startCommand() : defaultStart,
                profiling.stopCommand()  != null ? profiling.stopCommand()  : defaultStop,
                output,
                profiling.perf(),
                runDir
        );
    }

    public void startBeforeMeasurement() throws IOException {
        if (!enabled) return;
        if ("beforeMeasurement".equalsIgnoreCase(start)) {
            startRecording();
        }
    }

    public void stopAfterMeasurement() throws IOException {
        if (!enabled) return;
        if ("afterMeasurement".equalsIgnoreCase(stop)) {
            dumpAndClose();
        }
    }

    public Path outputFile() {
        return outputFile;
    }

    /**
     * Resolved path where {@code perf record} will write its output for
     * this run, or {@code null} if perf is disabled / not configured.
     * The file only exists after {@link #stopAfterMeasurement()} returns.
     */
    public Path perfOutputFile() {
        if (perfConfig == null || !perfConfig.enabled() || runDir == null) return null;
        String name = perfConfig.filenameOrDefault().replace("${runName}", runName);
        return runDir.resolve(name);
    }

    /** @return {@code true} if perf is enabled for this run. */
    public boolean perfEnabled() {
        return perfConfig != null && perfConfig.enabled();
    }

    @Override
    public void close() throws IOException {
        if (!enabled || dumped) return;
        dumpAndClose();
    }

    /* ================================================================
     *  Start / stop dispatch
     * ================================================================ */

    private void startRecording() throws IOException {
        // 1. Start perf BEFORE JFR so its sample window strictly contains JFR's.
        if (perfConfig != null && perfConfig.enabled()) {
            perfRecorder = PerfRecorder.start(perfConfig, runName, runDir);
        }
        try {
            if (useApi) {
                startWithApi();
            } else {
                executeJcmdArgs(buildDefaultJcmdArgs(true), startCommandTemplate);
            }
        } catch (RuntimeException | IOException e) {
            // JFR failed to start — do not leave a perf child sampling a
            // window that will never be closed. Best-effort cleanup, then
            // propagate the original JFR failure.
            if (perfRecorder != null) {
                try { perfRecorder.stop(); } catch (IOException ignore) { /* swallowed */ }
                perfRecorder = null;
            }
            throw e;
        }
        // 2. Anchor event: emitted only at measurement start/end.
        //    nanoTime() is in the same clock domain as JFR events and perf
        //    samples (perf launched with -k monotonic).
        emitAnchor("start");
    }

    private void dumpAndClose() throws IOException {
        emitAnchor("stop");
        if (useApi) {
            stopWithApi();
        } else {
            executeJcmdArgs(buildDefaultJcmdArgs(false), stopCommandTemplate);
        }
        if (perfRecorder != null) {
            try {
                perfRecorder.stop();
            } finally {
                perfRecorder = null;
            }
        }
        dumped = true;
    }

    private void emitAnchor(String phase) {
        AnchorEvent ev = new AnchorEvent();
        ev.phase = phase;
        ev.runName = runName;
        ev.nanoTime = System.nanoTime();
        ev.epochMillis = System.currentTimeMillis();
        ev.commit();
    }

    /**
     * Custom JFR event marking the exact instant the recording window
     * opens and closes. Carries both {@code System.nanoTime()} (same clock
     * as {@code perf -k CLOCK_MONOTONIC}) and wall-clock millis, so an
     * external tool can align JFR and perf timelines deterministically.
     */
    @Name("com.scott.AnchorEvent")
    @Label("Benchmark Anchor")
    public static final class AnchorEvent extends Event {
        @Label("Phase")        public String phase;
        @Label("Run name")     public String runName;
        @Label("nanoTime")     public long   nanoTime;
        @Label("epochMillis")  public long   epochMillis;
    }

    /* ================================================================
     *  In-process JFR API back-end
     * ================================================================ */

    private void startWithApi() throws IOException {
        try {
            Configuration cfg = loadConfiguration(settings);
            Recording r = (cfg != null) ? new Recording(cfg) : new Recording();
            r.setName(runName);
            r.setDestination(outputFile);
            r.setToDisk(true);
            r.start();
            this.recording = r;
        } catch (ParseException e) {
            throw new IOException("Failed to load JFR configuration '" + settings + "'", e);
        }
    }

    private void stopWithApi() throws IOException {
        if (recording == null) return;
        try {
            // setDestination(outputFile) was configured before start(); stop()
            // flushes the final chunk to that path. Calling dump() afterwards
            // would re-serialize the recording and double the I/O on the
            // measurement-boundary thread, so we no longer do it.
            recording.stop();
        } finally {
            recording.close();
            recording = null;
        }
    }

    /**
     * Resolves a JFR {@link Configuration}. Accepts a built-in preset
     * name ({@code "default"}, {@code "profile"}) or a path to a {@code .jfc}.
     */
    private static Configuration loadConfiguration(String settings) throws IOException, ParseException {
        if (settings == null || settings.isBlank()) {
            return Configuration.getConfiguration("default");
        }
        Path asPath = Paths.get(settings);
        if (Files.exists(asPath)) {
            return Configuration.create(asPath);
        }
        return Configuration.getConfiguration(settings);
    }

    /* ================================================================
     *  jcmd back-end
     * ================================================================ */

    private String expand(String template) {
        return template
                .replace("${runName}",    runName)
                .replace("${settings}",   settings)
                .replace("${outputFile}", outputFile.toString());
    }

    /**
     * Builds the argv for the <em>default</em> jcmd invocation without
     * whitespace splitting. Each key=value token is a distinct argv
     * element, which is what {@code jcmd} expects and which is robust
     * against run paths that contain spaces.
     */
    private List<String> buildDefaultJcmdArgs(boolean start) {
        List<String> args = new ArrayList<>(4);
        if (start) {
            args.add("JFR.start");
            args.add("name=" + runName);
            args.add("settings=" + settings);
            args.add("filename=" + outputFile.toString());
        } else {
            args.add("JFR.stop");
            args.add("name=" + runName);
            args.add("filename=" + outputFile.toString());
        }
        return args;
    }

    /**
     * Runs a jcmd command. If the user supplied a custom template
     * ({@code profiling.startCommand} / {@code stopCommand}) that differs
     * from the built-in default, we fall back to whitespace splitting of
     * the expanded template (legacy behaviour). Otherwise we use the
     * pre-built argv list, which is safe against spaces in paths.
     */
    private void executeJcmdArgs(List<String> defaultArgs, String userTemplate) throws IOException {
        boolean isDefault =
                "JFR.start name=${runName} settings=${settings} filename=${outputFile}".equals(userTemplate)
             || "JFR.stop name=${runName} filename=${outputFile}".equals(userTemplate);

        List<String> jfrArgs = isDefault
                ? defaultArgs
                : Arrays.asList(expand(userTemplate).trim().split("\\s+"));
        executeJcmd(jfrArgs);
    }

    /**
     * Resolves the {@code jcmd} executable. Prefers
     * {@code $JAVA_HOME/bin/jcmd} so {@code PATH} is not required; falls
     * back to a bare {@code "jcmd"} for the OS resolver.
     */
    private static String resolveJcmd() {
        String javaHome = System.getProperty("java.home");
        if (javaHome != null && !javaHome.isBlank()) {
            String name = System.getProperty("os.name", "").toLowerCase().contains("win")
                    ? "jcmd.exe" : "jcmd";
            Path candidate = Paths.get(javaHome, "bin", name);
            if (Files.isExecutable(candidate)) {
                return candidate.toString();
            }
        }
        return "jcmd";
    }

    private static void executeJcmd(List<String> jfrArgs) throws IOException {
        long pid = ProcessHandle.current().pid();
        List<String> parts = new ArrayList<>(jfrArgs.size() + 2);
        parts.add(resolveJcmd());
        parts.add(String.valueOf(pid));
        parts.addAll(jfrArgs);

        Process process;
        try {
            process = new ProcessBuilder(parts).redirectErrorStream(true).start();
        } catch (IOException e) {
            throw new IOException(
                    "Failed to launch jcmd (" + parts.get(0) + "). "
                            + "You are likely on a JRE or jcmd is not on PATH. "
                            + "Either run on a full JDK, or set profiling.control: api "
                            + "in your YAML to use the in-process JFR Recording API.",
                    e);
        }

        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append(System.lineSeparator());
            }
        }

        try {
            int exit = process.waitFor();
            if (exit != 0) {
                throw new IOException("jcmd command failed (exit=" + exit + "): " + String.join(" ", parts)
                        + System.lineSeparator() + output);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted while waiting for jcmd command", e);
        }
    }
}

