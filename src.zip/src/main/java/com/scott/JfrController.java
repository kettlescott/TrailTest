package com.scott;

import jdk.jfr.Configuration;
import jdk.jfr.Recording;
import jdk.jfr.RecordingState;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.ParseException;

public final class JfrController implements AutoCloseable {

    private final boolean enabled;
    private final String start;
    private final String stop;
    private final Path outputFile;
    private final Recording recording;
    private boolean dumped;

    private JfrController(boolean enabled, String start, String stop, Path outputFile, Recording recording) {
        this.enabled = enabled;
        this.start = start;
        this.stop = stop;
        this.outputFile = outputFile;
        this.recording = recording;
    }

    public static JfrController create(ProfilingConfig profiling, String runName, Path runDir) throws IOException {
        if (profiling == null || !profiling.enabled()) {
            return new JfrController(false, null, null, null, null);
        }

        String resolvedName = profiling.filename().replace("${runName}", runName);
        Path output = runDir.resolve(resolvedName);
        Files.createDirectories(output.getParent());

        Recording recording;
        try {
            recording = new Recording(Configuration.getConfiguration(profiling.settings()));
        } catch (ParseException e) {
            throw new IOException("Unable to load JFR settings: " + profiling.settings(), e);
        }
        return new JfrController(true, profiling.start(), profiling.stop(), output, recording);
    }

    public void startBeforeMeasurement() {
        if (!enabled) return;
        if ("beforeMeasurement".equalsIgnoreCase(start)) {
            recording.start();
        }
    }

    public void stopAfterMeasurement() throws IOException {
        if (!enabled) return;
        if ("afterMeasurement".equalsIgnoreCase(stop)) {
            dumpAndClose();
        }
    }

    public Path outputFile() {
        return outputFile;
    }

    @Override
    public void close() throws IOException {
        if (!enabled || dumped) return;
        dumpAndClose();
    }

    private void dumpAndClose() throws IOException {
        try {
            if (recording.getState() == RecordingState.RUNNING) {
                recording.stop();
            }
            if (recording.getState() == RecordingState.STOPPED) {
                recording.dump(outputFile);
            }
        } finally {
            recording.close();
            dumped = true;
        }
    }
}

