package com.scott;

public record RunConfig(
        String name,
        String mode,
        String workload
) {
    public void validate() {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("runs[].name is required");
        }
        if (mode == null || mode.isBlank()) {
            throw new IllegalArgumentException("runs[" + name + "].mode is required");
        }
        if (workload == null || workload.isBlank()) {
            throw new IllegalArgumentException("runs[" + name + "].workload is required");
        }
        BenchmarkMode.fromConfigValue(mode);
    }
}

