package com.scott;

import java.util.SplittableRandom;

public final class TaskGenerator {

	private final WorkloadConfig workload;
	private final int baseIterations;
	private final long seed;

	public TaskGenerator(WorkloadConfig workload, int baseIterations, long seed) {
		this.workload = workload;
		this.baseIterations = baseIterations;
		this.seed = seed;
	}

	public TaskType taskTypeFor(long taskId) {
		if (workload.isSingle()) {
			return TaskType.fromLabel(workload.type());
		}

		int shortPct = workload.valueFor("short");
		int mediumPct = workload.valueFor("medium");
		int draw = drawPercent(taskId);
		if (draw < shortPct) {
			return TaskType.SHORT;
		}
		if (draw < shortPct + mediumPct) {
			return TaskType.MEDIUM;
		}
		return TaskType.LONG;
	}

	public Task nextTask(long taskId, boolean measurement, Runnable onComplete) {
		TaskType type = taskTypeFor(taskId);
		int iterations = Math.max(1, baseIterations * type.iterationMultiplier());
		long submitNanos = System.nanoTime();
		long taskSeed = seed + taskId;
		Workload workloadImpl = new CpuBoundWorkload(taskSeed, iterations);
		return new Task(taskId, type, iterations, submitNanos, measurement, workloadImpl, onComplete);
	}

	private int drawPercent(long taskId) {
		if (!"shuffled".equalsIgnoreCase(workload.generation())) {
			throw new IllegalArgumentException("Only generation=shuffled is currently supported");
		}
		SplittableRandom random = new SplittableRandom(seed ^ (taskId * 0x9E3779B97F4A7C15L));
		return random.nextInt(100);
	}
}

