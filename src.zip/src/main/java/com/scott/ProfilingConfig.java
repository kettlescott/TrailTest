package com.scott;

public record ProfilingConfig(
        boolean enabled,
        String settings,
        String start,
        String stop,
        String filename
) {
    public void validate() {
        if (!enabled) {
            return;
        }
        if (settings == null || settings.isBlank()) {
            throw new IllegalArgumentException("profiling.settings is required when profiling is enabled");
        }
        if (start == null || start.isBlank()) {
            throw new IllegalArgumentException("profiling.start is required when profiling is enabled");
        }
        if (stop == null || stop.isBlank()) {
            throw new IllegalArgumentException("profiling.stop is required when profiling is enabled");
        }
        if (!"beforeMeasurement".equalsIgnoreCase(start)) {
            throw new IllegalArgumentException("profiling.start currently supports only 'beforeMeasurement'");
        }
        if (!"afterMeasurement".equalsIgnoreCase(stop)) {
            throw new IllegalArgumentException("profiling.stop currently supports only 'afterMeasurement'");
        }
        if (filename == null || filename.isBlank()) {
            throw new IllegalArgumentException("profiling.filename is required when profiling is enabled");
        }
    }
}

